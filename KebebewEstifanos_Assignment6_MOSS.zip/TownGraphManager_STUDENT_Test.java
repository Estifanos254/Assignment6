
package application;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Test class for TownGraphManager.
 * 
 */
public class TownGraphManager_STUDENT_Test {

  private TownGraphManagerInterface graph;

  /**
   * Setup method to initialize graph.
   * 
   * @throws Exception if an exception occurs during setup
   */
  @Before
  public void setUp() throws Exception {
    graph = new TownGraphManager();
    graph.addTown("Town1");
    graph.addTown("Town2");
    graph.addTown("Town3");
    graph.addTown("Town4");
    graph.addRoad("Town1", "Town2", 2, "Road1");
    graph.addRoad("Town1", "Town3", 4, "Road2");
    graph.addRoad("Town2", "Town3", 1, "Road3");
    graph.addRoad("Town3", "Town4", 2, "Road4");
  }

  /**
   * Teardown method to clean up after each test.
   * 
   * @throws Exception if an exception occurs during teardown
   */
  @After
  public void tearDown() throws Exception {
    graph = null;
  }

  /**
   * Test addRoad() method.
   */
  @Test
  public void testAddRoad() {
    assertTrue(graph.addRoad("Town1", "Town4", 3, "Road5"));
    assertFalse(graph.addRoad("Town1", "Town4", 5, "Road6"));
    assertTrue(graph.containsRoadConnection("Town1", "Town4"));
  }
 
  /**
   * Test addTown() method.
   */
  @Test
  public void testAddTown() {
    assertTrue(graph.addTown("Town5"));
    assertFalse(graph.addTown("Town1"));
  }

  /**
   * Test getTown() method.
   */
  @Test
  public void testGetTown() {
    assertEquals("Town1", graph.getTown("Town1").getName());
    assertNull(graph.getTown("Town6"));
  }

  /**
   * Test containsTown() method.
   */
  @Test
  public void testContainsTown() {
    assertTrue(graph.containsTown("Town3"));
    assertFalse(graph.containsTown("Town5"));
  }

  /**
   * Test containsRoadConnection() method.
   */
  @Test
  public void testContainsRoadConnection() {
    assertTrue(graph.containsRoadConnection("Town1", "Town2"));
    assertFalse(graph.containsRoadConnection("Town1", "Town4"));
  }

  /**
   * Test allRoads() method.
   */
  @Test
  public void testAllRoads() {
    ArrayList<String> roads = graph.allRoads();
    assertEquals("Road1", roads.get(0));
    assertEquals("Road2", roads.get(1));
    assertEquals("Road3", roads.get(2));
    assertEquals("Road4", roads.get(3));
  }

 
}

